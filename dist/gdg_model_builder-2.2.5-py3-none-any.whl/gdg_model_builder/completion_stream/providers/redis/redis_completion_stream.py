from ...completion_stream import CompletionStream

class RedisCompletionStream(CompletionStream):
    pass