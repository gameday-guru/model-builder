import collections
from enum import Enum
from typing import Sequence, TypeVar, Generic, Dict, Tuple, Iterable, Optional

class Watcher():
    pass