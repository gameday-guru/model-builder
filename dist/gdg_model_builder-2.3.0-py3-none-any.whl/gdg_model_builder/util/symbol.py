class Symbol:
    pass