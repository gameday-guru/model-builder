class Set:
    pass