# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['model_builder',
 'model_builder.context.bounds',
 'model_builder.context.bounds.execution',
 'model_builder.context.bounds.session',
 'model_builder.context.bounds.user',
 'model_builder.context.context',
 'model_builder.context.execution',
 'model_builder.context.session',
 'model_builder.context.user',
 'model_builder.event',
 'model_builder.libutil',
 'model_builder.libutil.np',
 'model_builder.libutil.sync',
 'model_builder.model',
 'model_builder.model_builder_cli',
 'model_builder.modifiers',
 'model_builder.sdk',
 'model_builder.sdk.ncaab']

package_data = \
{'': ['*'], 'model_builder.model_builder_cli': ['assets/docker/*']}

install_requires = \
['attrs>=21.4.0,<22.0.0',
 'cattrs>=22.1.0,<23.0.0',
 'fastapi[all]>=0.78.0,<0.79.0',
 'numpy>=1.23.0,<2.0.0',
 'pycron>=3.0.0,<4.0.0',
 'redis>=4.3.4,<5.0.0']

setup_kwargs = {
    'name': 'model-builder',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Liam Monninger',
    'author_email': 'l.mak.monninger@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>3.9,<4.0',
}


setup(**setup_kwargs)
